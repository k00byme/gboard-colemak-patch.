package app.gboard.colemak;

import android.content.Context;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceCategory;
import android.preference.PreferenceScreen;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Toast;

import java.util.Locale;

@SuppressWarnings("deprecation")
public final class QwertzSettingsActivity extends PreferenceActivity {
    private static final String KEY_TOP = "qwertz_top_row";
    private static final String KEY_MIDDLE = "qwertz_middle_row";
    private static final String KEY_BOTTOM = "qwertz_bottom_row";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("Personalizar QWERTZ");

        // Match the default preference file used by Gboard's own settings screens.
        getPreferenceManager().setSharedPreferencesName(getPackageName() + "_preferences");
        getPreferenceManager().setSharedPreferencesMode(Context.MODE_PRIVATE);

        PreferenceScreen screen = getPreferenceManager().createPreferenceScreen(this);
        PreferenceCategory rows = new PreferenceCategory(this);
        rows.setTitle("Ordem das letras");
        screen.addPreference(rows);

        addRow(rows, KEY_TOP, "Fileira superior", "10 letras, sem espaços", "qwertzuiop", 10);
        addRow(rows, KEY_MIDDLE, "Fileira do meio", "9 letras, sem espaços", "asdfghjkl", 9);
        addRow(rows, KEY_BOTTOM, "Fileira inferior", "7 letras, sem espaços", "yxcvbnm", 7);

        Preference rule = new Preference(this);
        rule.setTitle("Regra de validação");
        rule.setSummary("As três fileiras precisam usar todas as letras de a a z exatamente uma vez. Depois de salvar, feche e abra o teclado novamente.");
        rule.setSelectable(false);
        rows.addPreference(rule);

        setPreferenceScreen(screen);
    }

    private void addRow(PreferenceCategory category, String key, String title,
            String description, String defaultValue, int expectedLength) {
        EditTextPreference preference = new EditTextPreference(this);
        preference.setKey(key);
        preference.setTitle(title);
        preference.setDialogTitle(title);
        preference.setDialogMessage(description);
        preference.setDefaultValue(defaultValue);
        preference.setPersistent(true);
        preference.setSummary("Toque para editar a sequência de letras.");
        preference.setOnPreferenceChangeListener((item, newValue) -> {
            String value = String.valueOf(newValue).toLowerCase(Locale.ROOT);
            if (!isValidRow(value, expectedLength)) {
                Toast.makeText(this,
                        "Digite " + expectedLength + " letras diferentes, sem espaços.",
                        Toast.LENGTH_LONG).show();
                return false;
            }
            return true;
        });
        preference.getEditText().setInputType(
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        category.addPreference(preference);
    }

    private static boolean isValidRow(String value, int expectedLength) {
        if (value == null || value.length() != expectedLength) return false;
        boolean[] seen = new boolean[26];
        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            if (character < 'a' || character > 'z') return false;
            int index = character - 'a';
            if (seen[index]) return false;
            seen[index] = true;
        }
        return true;
    }
}
