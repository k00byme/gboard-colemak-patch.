package app.gboard.colemak;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.util.SparseArray;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Runtime bridge called when Gboard creates a KeyMappingDef from layout XML. */
public final class QwertzLayoutRuntime {
    private static final String TAG = "QwertzCustomLayout";
    private static final String DEFAULT_LAYOUT = "qwertzuiopasdfghjklyxcvbnm";
    private static final int[] VIEW_IDS = {
            0x7f0b0039, 0x7f0b003a, 0x7f0b003b, 0x7f0b003c, 0x7f0b003e,
            0x7f0b0040, 0x7f0b0042, 0x7f0b0043, 0x7f0b0044, 0x7f0b0045,
            0x7f0b0024, 0x7f0b0025, 0x7f0b0026, 0x7f0b0027, 0x7f0b0029,
            0x7f0b002b, 0x7f0b002d, 0x7f0b002e, 0x7f0b002f,
            0x7f0b000e, 0x7f0b000f, 0x7f0b0011, 0x7f0b0013, 0x7f0b0015,
            0x7f0b0017, 0x7f0b0018,
    };
    private static final int SPLIT_MIDDLE_VIEW_ID = 0x7f0b002a;
    private static final int SPLIT_BOTTOM_VIEW_ID = 0x7f0b0014;

    private static final int[] LOWERCASE_KEY_IDS = {
            0x7f0b198e, 0x7f0b19fe, 0x7f0b1905, 0x7f0b1992, 0x7f0b19c5,
            0x7f0b1a0d, 0x7f0b19e6, 0x7f0b1934, 0x7f0b1971, 0x7f0b1987,
            0x7f0b18d4, 0x7f0b199d, 0x7f0b18f7, 0x7f0b191b, 0x7f0b191f,
            0x7f0b192e, 0x7f0b1945, 0x7f0b1949, 0x7f0b1951,
            0x7f0b1a06, 0x7f0b1a03, 0x7f0b18e9, 0x7f0b19fb, 0x7f0b18e4,
            0x7f0b1965, 0x7f0b195e,
    };
    private static final int[] UPPERCASE_KEY_IDS = {
            0x7f0b1877, 0x7f0b18a5, 0x7f0b1813, 0x7f0b1878, 0x7f0b1886,
            0x7f0b18ad, 0x7f0b1890, 0x7f0b1838, 0x7f0b1860, 0x7f0b1875,
            0x7f0b17f7, 0x7f0b187d, 0x7f0b180f, 0x7f0b1826, 0x7f0b1828,
            0x7f0b1833, 0x7f0b1849, 0x7f0b184b, 0x7f0b184f,
            0x7f0b18a9, 0x7f0b18a8, 0x7f0b1808, 0x7f0b18a3, 0x7f0b1806,
            0x7f0b1857, 0x7f0b1853,
    };

    private QwertzLayoutRuntime() { }

    public static void apply(Object keyMappingDef) {
        try {
            String[] rows = readRows();
            if (!validRows(rows)) return;

            int changed = 0;
            for (Field mappingField : keyMappingDef.getClass().getDeclaredFields()) {
                if (Modifier.isStatic(mappingField.getModifiers()) ||
                        !SparseArray.class.isAssignableFrom(mappingField.getType())) {
                    continue;
                }
                mappingField.setAccessible(true);
                Object value = mappingField.get(keyMappingDef);
                if (!(value instanceof SparseArray)) continue;
                SparseArray<?> mappings = (SparseArray<?>) value;
                if (remapIfStock(mappings, LOWERCASE_KEY_IDS, rows) ||
                        remapIfStock(mappings, UPPERCASE_KEY_IDS, rows)) {
                    changed++;
                }
            }
            if (changed > 0) Log.i(TAG, "Applied custom QWERTZ rows to " + changed + " mapping group(s)");
        } catch (Throwable throwable) {
            // A layout patch must never prevent Gboard from opening its keyboard.
            Log.w(TAG, "Could not apply custom QWERTZ mapping; using stock layout", throwable);
        }
    }

    private static boolean remapIfStock(SparseArray<?> mappings, int[] keyIds, String[] rows)
            throws Exception {
        if (mappings.size() < VIEW_IDS.length) return false;

        Map<Integer, Object> definitionsById = new HashMap<>();
        for (int i = 0; i < mappings.size(); i++) {
            Object mappingEntry = mappings.valueAt(i);
            if (mappingEntry == null) continue;
            int keyId = resolveSoftKeyId(mappingEntry);
            if (keyId != 0) definitionsById.put(keyId, mappingEntry);
        }
        if (definitionsById.isEmpty()) return false;

        // Only touch the original QWERTZ resource. Other layouts such as QWERTY remain unchanged.
        for (int i = 0; i < VIEW_IDS.length; i++) {
            Object current = mappings.get(VIEW_IDS[i]);
            if (current == null || resolveSoftKeyId(current) != keyIds[i]) return false;
        }

        String allLetters = rows[0] + rows[1] + rows[2];
        for (int i = 0; i < VIEW_IDS.length; i++) {
            int sourceIndex = DEFAULT_LAYOUT.indexOf(allLetters.charAt(i));
            if (sourceIndex < 0) return false;
            Object definition = definitionsById.get(keyIds[sourceIndex]);
            if (definition == null) return false;
            ((SparseArray<Object>) mappings).put(VIEW_IDS[i], definition);
        }

        Object splitMiddle = definitionsById.get(
                keyIds[DEFAULT_LAYOUT.indexOf(rows[1].charAt(4))]);
        Object splitBottom = definitionsById.get(
                keyIds[DEFAULT_LAYOUT.indexOf(rows[2].charAt(3))]);
        if (splitMiddle != null) ((SparseArray<Object>) mappings).put(SPLIT_MIDDLE_VIEW_ID, splitMiddle);
        if (splitBottom != null) ((SparseArray<Object>) mappings).put(SPLIT_BOTTOM_VIEW_ID, splitBottom);
        return true;
    }

    /**
     * Gboard wraps each SoftKeyDef in qbo -> qbp before storing it in KeyMappingDef.
     * Keep the wrapper object when moving entries so its state metadata is preserved.
     */
    private static int resolveSoftKeyId(Object mappingEntry) throws Exception {
        Object current = mappingEntry;
        for (int depth = 0; depth < 3 && current != null; depth++) {
            try {
                Field id = current.getClass().getDeclaredField("f");
                if (id.getType() == Integer.TYPE) {
                    id.setAccessible(true);
                    return id.getInt(current);
                }
            } catch (NoSuchFieldException ignored) {
                // Continue through Gboard's small wrapper objects.
            }
            try {
                Field wrapped = current.getClass().getDeclaredField("a");
                wrapped.setAccessible(true);
                current = wrapped.get(current);
            } catch (NoSuchFieldException missingWrapper) {
                return 0;
            }
        }
        return 0;
    }

    private static String[] readRows() throws Exception {
        Application application = currentApplication();
        SharedPreferences preferences = application.getSharedPreferences(
                application.getPackageName() + "_preferences", Context.MODE_PRIVATE);
        return new String[] {
                preferences.getString("qwertz_top_row", "qwertzuiop").toLowerCase(Locale.ROOT),
                preferences.getString("qwertz_middle_row", "asdfghjkl").toLowerCase(Locale.ROOT),
                preferences.getString("qwertz_bottom_row", "yxcvbnm").toLowerCase(Locale.ROOT),
        };
    }

    private static Application currentApplication() throws Exception {
        Class<?> activityThread = Class.forName("android.app.ActivityThread");
        Method currentApplication = activityThread.getDeclaredMethod("currentApplication");
        currentApplication.setAccessible(true);
        Object application = currentApplication.invoke(null);
        if (!(application instanceof Application)) {
            throw new IllegalStateException("Gboard Application context is unavailable");
        }
        return (Application) application;
    }

    private static boolean validRows(String[] rows) {
        if (rows == null || rows.length != 3 || rows[0].length() != 10 ||
                rows[1].length() != 9 || rows[2].length() != 7) return false;
        boolean[] seen = new boolean[26];
        for (String row : rows) {
            for (int i = 0; i < row.length(); i++) {
                char letter = row.charAt(i);
                if (letter < 'a' || letter > 'z') return false;
                int index = letter - 'a';
                if (seen[index]) return false;
                seen[index] = true;
            }
        }
        for (boolean present : seen) if (!present) return false;
        return true;
    }
}
